

<?php $__env->startSection('title', 'Edit Fixture'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto">
    <div class="bg-white rounded-3xl p-8 shadow-sm border border-zinc-100">
        <form action="<?php echo e(route('admin.fixtures.update', $match->id)); ?>" method="POST" class="space-y-6">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            
            <!-- Alerts -->
            <?php if(session('success')): ?>
                <div class="mb-8 bg-emerald-50 border border-emerald-100 p-4 rounded-2xl flex items-center gap-3">
                    <div class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                    <span class="text-emerald-700 text-xs font-bold uppercase tracking-widest"><?php echo e(session('success')); ?></span>
                </div>
            <?php endif; ?>

            <div class="grid grid-cols-2 gap-8">
                <div class="space-y-2">
                    <label class="block text-[10px] font-black text-zinc-400 border-b border-zinc-50 pb-2 uppercase tracking-widest">Home Team</label>
                    <select name="home_team_id" class="w-full bg-zinc-50 border border-zinc-100 p-4 rounded-xl font-bold text-primary focus:ring-2 focus:ring-primary outline-none transition uppercase text-xs" required>
                        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($team->id); ?>" <?php echo e($match->home_team_id == $team->id ? 'selected' : ''); ?>><?php echo e($team->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="space-y-2">
                    <label class="block text-[10px] font-black text-zinc-400 border-b border-zinc-50 pb-2 uppercase tracking-widest">Away Team</label>
                    <select name="away_team_id" class="w-full bg-zinc-50 border border-zinc-100 p-4 rounded-xl font-bold text-primary focus:ring-2 focus:ring-primary outline-none transition uppercase text-xs" required>
                        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($team->id); ?>" <?php echo e($match->away_team_id == $team->id ? 'selected' : ''); ?>><?php echo e($team->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="grid grid-cols-2 gap-8">
                <div class="space-y-2">
                    <label class="block text-[10px] font-black text-zinc-400 border-b border-zinc-50 pb-2 uppercase tracking-widest">Match Date & Time</label>
                    <input type="datetime-local" name="match_date" value="<?php echo e($match->match_date->format('Y-m-d\TH:i')); ?>" class="w-full bg-zinc-50 border border-zinc-100 p-4 rounded-xl font-bold text-primary focus:ring-2 focus:ring-primary outline-none transition text-xs" required>
                </div>
                <div class="space-y-2">
                    <label class="block text-[10px] font-black text-zinc-400 border-b border-zinc-50 pb-2 uppercase tracking-widest">Venue</label>
                    <input type="text" name="venue" value="<?php echo e($match->venue); ?>" class="w-full bg-zinc-50 border border-zinc-100 p-4 rounded-xl font-bold text-primary focus:ring-2 focus:ring-primary outline-none transition uppercase text-xs">
                </div>
            </div>

            <div class="grid grid-cols-2 gap-8">
                <div class="space-y-2">
                    <label class="block text-[10px] font-black text-zinc-400 border-b border-zinc-50 pb-2 uppercase tracking-widest">Tournament Stage</label>
                    <select name="stage" class="w-full bg-zinc-50 border border-zinc-100 p-4 rounded-xl font-bold text-primary focus:ring-2 focus:ring-primary outline-none transition uppercase text-xs" required>
                        <option value="group" <?php echo e($match->stage == 'group' ? 'selected' : ''); ?>>Group Stage</option>
                        <option value="semifinal" <?php echo e($match->stage == 'semifinal' ? 'selected' : ''); ?>>Semi-Final</option>
                        <option value="final" <?php echo e($match->stage == 'final' ? 'selected' : ''); ?>>Grand Final</option>
                        <option value="novelty" <?php echo e($match->stage == 'novelty' ? 'selected' : ''); ?>>Novelty Match</option>
                    </select>
                </div>
                <div class="space-y-2">
                    <label class="block text-[10px] font-black text-zinc-400 border-b border-zinc-50 pb-2 uppercase tracking-widest">Match Status</label>
                    <select name="status" class="w-full bg-zinc-50 border border-zinc-100 p-4 rounded-xl font-bold text-primary focus:ring-2 focus:ring-primary outline-none transition uppercase text-xs" required>
                        <option value="upcoming" <?php echo e($match->status == 'upcoming' ? 'selected' : ''); ?>>Upcoming</option>
                        <option value="finished" <?php echo e($match->status == 'finished' ? 'selected' : ''); ?>>Finished</option>
                    </select>
                </div>
            </div>

            <div class="grid grid-cols-2 gap-8">
                <div class="space-y-2">
                    <label class="block text-[10px] font-black text-zinc-400 border-b border-zinc-50 pb-2 uppercase tracking-widest">Referee</label>
                    <input type="text" name="referee" value="<?php echo e($match->referee); ?>" class="w-full bg-zinc-50 border border-zinc-100 p-4 rounded-xl font-bold text-primary focus:ring-2 focus:ring-primary outline-none transition uppercase text-xs" placeholder="Who is the Ref?">
                </div>
                <div class="space-y-2">
                    <label class="block text-[10px] font-black text-zinc-400 border-b border-zinc-50 pb-2 uppercase tracking-widest">Attendance</label>
                    <input type="number" name="attendance" value="<?php echo e($match->attendance); ?>" class="w-full bg-zinc-50 border border-zinc-100 p-4 rounded-xl font-bold text-primary focus:ring-2 focus:ring-primary outline-none transition uppercase text-xs" placeholder="e.g. 50000">
                </div>
            </div>

            <!-- Lineup Selection (Stable Plain HTML) -->
            <div class="mt-12 space-y-8">
                <div class="flex items-center justify-between border-b border-zinc-50 pb-4">
                    <h3 class="text-xs font-black text-primary uppercase tracking-widest">Match Squads & Positions</h3>
                    <div class="flex gap-4 text-[9px] font-bold text-zinc-400 uppercase tracking-widest">
                        <span>● Start</span>
                        <span>○ Sub</span>
                        <span>✕ Out</span>
                    </div>
                </div>
                
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-12">
                    <!-- Home Team Players -->
                    <div class="space-y-4">
                        <div class="flex items-center justify-between">
                            <h4 class="text-[10px] font-black text-indigo-600 uppercase tracking-widest"><?php echo e($match->homeTeam->name); ?></h4>
                            <span class="text-[9px] font-bold text-zinc-300 uppercase tracking-widest">Manager: <?php echo e($match->homeTeam->manager); ?></span>
                        </div>
                        <div class="bg-zinc-50 rounded-3xl p-2 max-h-[500px] overflow-y-auto no-scrollbar border border-zinc-100">
                            <table class="w-full">
                                <tbody class="divide-y divide-zinc-100">
                                    <?php 
                                        $homeLineup = $match->lineups->where('pivot.team_id', $match->home_team_id);
                                    ?>
                                    <?php $__currentLoopData = $match->homeTeam->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php 
                                            $pLineup = $homeLineup->where('id', $player->id)->first();
                                            $status = $pLineup ? ($pLineup->pivot->is_substitute ? 'sub' : 'start') : 'none';
                                            $savedX = $pLineup->pivot->position_x ?? null;
                                            $savedY = $pLineup->pivot->position_y ?? null;
                                            
                                            // Identify position from coords for selection
                                            $currentPos = 'GK'; // Default if GK coords
                                            foreach($positions as $key => $coords) {
                                                if ($coords['x'] == $savedX && $coords['y'] == $savedY) { $currentPos = $key; break; }
                                            }
                                        ?>
                                        <tr class="group hover:bg-white transition">
                                            <td class="py-3 px-4">
                                                <div class="flex items-center gap-3">
                                                    <span class="text-[10px] font-black text-zinc-300 w-4">#<?php echo e($player->shirt_number); ?></span>
                                                    <span class="text-xs font-bold text-primary uppercase"><?php echo e($player->name); ?></span>
                                                </div>
                                            </td>
                                            <td class="py-3 px-2">
                                                <div class="flex items-center gap-1 bg-white p-1 rounded-lg border border-zinc-200">
                                                    <label class="cursor-pointer">
                                                        <input type="radio" name="lineup[<?php echo e($player->id); ?>][status]" value="start" <?php echo e($status == 'start' ? 'checked' : ''); ?> class="hidden peer">
                                                        <div class="w-6 h-6 rounded-md flex items-center justify-center text-[10px] font-black peer-checked:bg-indigo-600 peer-checked:text-white text-zinc-300 hover:bg-zinc-50 transition">XI</div>
                                                    </label>
                                                    <label class="cursor-pointer">
                                                        <input type="radio" name="lineup[<?php echo e($player->id); ?>][status]" value="sub" <?php echo e($status == 'sub' ? 'checked' : ''); ?> class="hidden peer">
                                                        <div class="w-6 h-6 rounded-md flex items-center justify-center text-[10px] font-black peer-checked:bg-amber-500 peer-checked:text-white text-zinc-300 hover:bg-zinc-50 transition">S</div>
                                                    </label>
                                                    <label class="cursor-pointer">
                                                        <input type="radio" name="lineup[<?php echo e($player->id); ?>][status]" value="none" <?php echo e($status == 'none' ? 'checked' : ''); ?> class="hidden peer">
                                                        <div class="w-6 h-6 rounded-md flex items-center justify-center text-[10px] font-black peer-checked:bg-zinc-200 peer-checked:text-zinc-600 text-zinc-300 hover:bg-zinc-50 transition">✕</div>
                                                    </label>
                                                </div>
                                            </td>
                                            <td class="py-3 px-4">
                                                <select name="lineup[<?php echo e($player->id); ?>][position]" class="bg-white border border-zinc-200 rounded-lg text-[9px] font-black uppercase p-1.5 focus:ring-1 focus:ring-indigo-500 outline-none w-20">
                                                    <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $coords): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($key); ?>" <?php echo e($currentPos == $key ? 'selected' : ''); ?>><?php echo e($key); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Away Team Players -->
                    <div class="space-y-4">
                        <div class="flex items-center justify-between">
                            <h4 class="text-[10px] font-black text-rose-600 uppercase tracking-widest"><?php echo e($match->awayTeam->name); ?></h4>
                            <span class="text-[9px] font-bold text-zinc-300 uppercase tracking-widest">Manager: <?php echo e($match->awayTeam->manager); ?></span>
                        </div>
                        <div class="bg-zinc-50 rounded-3xl p-2 max-h-[500px] overflow-y-auto no-scrollbar border border-zinc-100">
                            <table class="w-full">
                                <tbody class="divide-y divide-zinc-100">
                                    <?php 
                                        $awayLineup = $match->lineups->where('pivot.team_id', $match->away_team_id);
                                    ?>
                                    <?php $__currentLoopData = $match->awayTeam->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php 
                                            $pLineup = $awayLineup->where('id', $player->id)->first();
                                            $status = $pLineup ? ($pLineup->pivot->is_substitute ? 'sub' : 'start') : 'none';
                                            $savedX = $pLineup->pivot->position_x ?? null;
                                            $savedY = $pLineup->pivot->position_y ?? null;
                                            
                                            // Identify position from coords (Reverse mapping for away team means 100-x)
                                            $currentPos = 'GK';
                                            foreach($positions as $key => $coords) {
                                                if ((100 - $coords['x']) == $savedX && $coords['y'] == $savedY) { $currentPos = $key; break; }
                                            }
                                        ?>
                                        <tr class="group hover:bg-white transition">
                                            <td class="py-3 px-4 text-right">
                                                <div class="flex items-center justify-end gap-3">
                                                    <span class="text-xs font-bold text-primary uppercase"><?php echo e($player->name); ?></span>
                                                    <span class="text-[10px] font-black text-zinc-300 w-4">#<?php echo e($player->shirt_number); ?></span>
                                                </div>
                                            </td>
                                            <td class="py-3 px-2">
                                                <div class="flex items-center gap-1 bg-white p-1 rounded-lg border border-zinc-200">
                                                    <label class="cursor-pointer">
                                                        <input type="radio" name="lineup[<?php echo e($player->id); ?>][status]" value="start" <?php echo e($status == 'start' ? 'checked' : ''); ?> class="hidden peer">
                                                        <div class="w-6 h-6 rounded-md flex items-center justify-center text-[10px] font-black peer-checked:bg-rose-600 peer-checked:text-white text-zinc-300 hover:bg-zinc-50 transition">XI</div>
                                                    </label>
                                                    <label class="cursor-pointer">
                                                        <input type="radio" name="lineup[<?php echo e($player->id); ?>][status]" value="sub" <?php echo e($status == 'sub' ? 'checked' : ''); ?> class="hidden peer">
                                                        <div class="w-6 h-6 rounded-md flex items-center justify-center text-[10px] font-black peer-checked:bg-amber-500 peer-checked:text-white text-zinc-300 hover:bg-zinc-50 transition">S</div>
                                                    </label>
                                                    <label class="cursor-pointer">
                                                        <input type="radio" name="lineup[<?php echo e($player->id); ?>][status]" value="none" <?php echo e($status == 'none' ? 'checked' : ''); ?> class="hidden peer">
                                                        <div class="w-6 h-6 rounded-md flex items-center justify-center text-[10px] font-black peer-checked:bg-zinc-200 peer-checked:text-zinc-600 text-zinc-300 hover:bg-zinc-50 transition">✕</div>
                                                    </label>
                                                </div>
                                            </td>
                                            <td class="py-3 px-4">
                                                <select name="lineup[<?php echo e($player->id); ?>][position]" class="bg-white border border-zinc-200 rounded-lg text-[9px] font-black uppercase p-1.5 focus:ring-1 focus:ring-rose-500 outline-none w-20">
                                                    <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $coords): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($key); ?>" <?php echo e($currentPos == $key ? 'selected' : ''); ?>><?php echo e($key); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Match Stats -->
            <div class="grid grid-cols-2 gap-12 bg-zinc-50 p-8 rounded-3xl border border-zinc-100 mt-12">
                <div class="space-y-6">
                    <div class="text-center">
                        <label class="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-2">Home Score</label>
                        <input type="number" name="home_score" value="<?php echo e($match->home_score); ?>" class="w-24 bg-white border border-zinc-200 p-4 rounded-2xl font-black text-primary text-3xl text-center focus:ring-2 focus:ring-secondary outline-none transition shadow-sm" min="0">
                    </div>
                    <div class="space-y-2">
                        <label class="block text-[10px] font-black text-zinc-400 uppercase tracking-widest">Possession %</label>
                        <input type="number" name="home_possession" value="<?php echo e($match->home_possession); ?>" class="w-full bg-white border border-zinc-200 p-4 rounded-xl font-bold text-primary text-xs" min="0" max="100">
                    </div>
                    <div class="space-y-2">
                        <label class="block text-[10px] font-black text-zinc-400 uppercase tracking-widest">Shots</label>
                        <input type="number" name="home_shots" value="<?php echo e($match->home_shots); ?>" class="w-full bg-white border border-zinc-200 p-4 rounded-xl font-bold text-primary text-xs" min="0">
                    </div>
                </div>
                <div class="space-y-6">
                    <div class="text-center">
                        <label class="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-2">Away Score</label>
                        <input type="number" name="away_score" value="<?php echo e($match->away_score); ?>" class="w-24 bg-white border border-zinc-200 p-4 rounded-2xl font-black text-primary text-3xl text-center focus:ring-2 focus:ring-secondary outline-none transition shadow-sm" min="0">
                    </div>
                    <div class="space-y-2">
                        <label class="block text-[10px] font-black text-zinc-400 uppercase tracking-widest">Possession %</label>
                        <input type="number" name="away_possession" value="<?php echo e($match->away_possession); ?>" class="w-full bg-white border border-zinc-200 p-4 rounded-xl font-bold text-primary text-xs" min="0" max="100">
                    </div>
                    <div class="space-y-2">
                        <label class="block text-[10px] font-black text-zinc-400 uppercase tracking-widest">Shots</label>
                        <input type="number" name="away_shots" value="<?php echo e($match->away_shots); ?>" class="w-full bg-white border border-zinc-200 p-4 rounded-xl font-bold text-primary text-xs" min="0">
                    </div>
                </div>
            </div>

            <div class="space-y-2 mt-8">
                <label class="block text-[10px] font-black text-zinc-400 border-b border-zinc-50 pb-2 uppercase tracking-widest">Match Report / Commentary</label>
                <textarea name="report" rows="6" class="w-full bg-zinc-50 border border-zinc-100 p-6 rounded-2xl font-medium text-primary text-xs focus:ring-2 focus:ring-primary outline-none transition"><?php echo e($match->report); ?></textarea>
            </div>

            <div class="space-y-4 bg-secondary/5 p-8 rounded-3xl border border-secondary/10">
                <label class="block text-[10px] font-black text-primary uppercase tracking-widest border-b border-secondary/20 pb-2">Man of the Match Award 🏆</label>
                <select name="motm_player_id" class="w-full bg-white border border-secondary/20 p-4 rounded-xl font-bold text-primary focus:ring-2 focus:ring-secondary outline-none transition uppercase text-xs shadow-sm">
                    <option value="">Select Man of the Match</option>
                    <optgroup label="<?php echo e($match->homeTeam->name); ?>">
                        <?php $__currentLoopData = $match->homeTeam->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->id); ?>" <?php echo e($match->motm_player_id == $p->id ? 'selected' : ''); ?>><?php echo e($p->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </optgroup>
                    <optgroup label="<?php echo e($match->awayTeam->name); ?>">
                        <?php $__currentLoopData = $match->awayTeam->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->id); ?>" <?php echo e($match->motm_player_id == $p->id ? 'selected' : ''); ?>><?php echo e($p->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </optgroup>
                </select>
            </div>

            <div class="flex items-center gap-4 pt-6 pb-6 border-b border-zinc-50 mb-6">
                <button type="submit" class="flex-1 bg-primary text-secondary font-black py-5 rounded-2xl hover:bg-primary-light transition uppercase tracking-widest text-xs shadow-lg">Save Match Data & Lineups</button>
                <a href="<?php echo e(route('admin.fixtures')); ?>" class="px-10 py-5 border border-zinc-200 rounded-2xl font-black text-[10px] text-zinc-400 uppercase tracking-widest hover:bg-zinc-50 transition">Cancel</a>
            </div>
        </form>

        <!-- Match Events Section -->
        <div class="mt-16 space-y-10">
            <h3 class="text-xs font-black text-primary uppercase tracking-widest border-b border-zinc-50 pb-4">Timeline Events (Goals, Cards, etc.)</h3>
            
            <form id="matchEventForm" action="<?php echo e(route('admin.matches.events.store', $match->id)); ?>" method="POST" enctype="multipart/form-data" class="bg-zinc-50 p-8 rounded-3xl border border-zinc-100 space-y-6">
                <?php echo csrf_field(); ?>
                <div class="grid grid-cols-3 gap-6">
                    <div class="space-y-2">
                        <label class="block text-[9px] font-black text-zinc-400 uppercase tracking-widest">Team</label>
                        <select name="team_id" class="w-full bg-white border border-zinc-200 p-4 rounded-xl font-bold text-primary text-xs" required>
                            <option value="<?php echo e($match->home_team_id); ?>"><?php echo e($match->homeTeam->name); ?></option>
                            <option value="<?php echo e($match->away_team_id); ?>"><?php echo e($match->awayTeam->name); ?></option>
                        </select>
                    </div>
                    <div class="space-y-2">
                        <label class="block text-[9px] font-black text-zinc-400 uppercase tracking-widest">Event Type</label>
                        <select id="eventTypeSelector" name="event_type" class="w-full bg-white border border-zinc-200 p-4 rounded-xl font-bold text-primary text-xs" required onchange="updateEventFields(this.value)">
                            <option value="goal">Goal</option>
                            <option value="penalty">Penalty</option>
                            <option value="yellow_card">Yellow Card</option>
                            <option value="red_card">Red Card</option>
                            <option value="sub_on">Substitution (On)</option>
                            <option value="sub_off">Substitution (Off)</option>
                        </select>
                    </div>
                    <div class="space-y-2">
                        <label class="block text-[9px] font-black text-zinc-400 uppercase tracking-widest">Minute</label>
                        <input type="number" name="minute" class="w-full bg-white border border-zinc-200 p-4 rounded-xl font-bold text-primary text-xs" min="0" max="120" placeholder="e.g. 45" required>
                    </div>
                </div>

                <div class="grid grid-cols-3 gap-6">
                    <div class="space-y-2">
                        <label id="mainPlayerLabel" class="block text-[9px] font-black text-zinc-400 uppercase tracking-widest">Main Player (Scorer/Carded)</label>
                        <select name="player_id" class="w-full bg-white border border-zinc-200 p-4 rounded-xl font-bold text-primary text-xs" required>
                            <option value="">Select Player</option>
                            <optgroup label="<?php echo e($match->homeTeam->name); ?>">
                                <?php $__currentLoopData = $match->homeTeam->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </optgroup>
                            <optgroup label="<?php echo e($match->awayTeam->name); ?>">
                                <?php $__currentLoopData = $match->awayTeam->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </optgroup>
                        </select>
                    </div>
                    <div class="space-y-2">
                        <div id="assistField">
                            <label class="block text-[9px] font-black text-zinc-400 uppercase tracking-widest">Assist By (Optional)</label>
                            <select name="assist_player_id" class="w-full bg-white border border-zinc-200 p-4 rounded-xl font-bold text-primary text-xs">
                                <option value="">No Assist</option>
                                <optgroup label="<?php echo e($match->homeTeam->name); ?>">
                                    <?php $__currentLoopData = $match->homeTeam->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </optgroup>
                                <optgroup label="<?php echo e($match->awayTeam->name); ?>">
                                    <?php $__currentLoopData = $match->awayTeam->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </optgroup>
                            </select>
                        </div>
                        <div id="subField" style="display: none;">
                            <label class="block text-[9px] font-black text-zinc-400 uppercase tracking-widest">Replacing (Player Off)</label>
                            <select name="related_player_id" class="w-full bg-white border border-zinc-200 p-4 rounded-xl font-bold text-primary text-xs">
                                <option value="">Select Player Off</option>
                                <optgroup label="<?php echo e($match->homeTeam->name); ?>">
                                    <?php $__currentLoopData = $match->homeTeam->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </optgroup>
                                <optgroup label="<?php echo e($match->awayTeam->name); ?>">
                                    <?php $__currentLoopData = $match->awayTeam->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </optgroup>
                            </select>
                        </div>
                    </div>
                    <div class="space-y-2">
                        <label class="block text-[9px] font-black text-zinc-400 uppercase tracking-widest">Photo (Overrides Profile Photo)</label>
                        <input type="file" name="player_image" class="w-full bg-white border border-zinc-200 p-4 rounded-xl font-bold text-primary text-[10px]" accept="image/*">
                    </div>
                </div>

                <button type="submit" class="w-full bg-secondary text-primary font-black py-4 rounded-2xl hover:bg-secondary-light transition uppercase tracking-widest text-xs shadow-md">Add Event to Timeline</button>
            </form>

            <script>
                function updateEventFields(type) {
                    const label = document.getElementById('mainPlayerLabel');
                    const assist = document.getElementById('assistField');
                    const sub = document.getElementById('subField');

                    if (type === 'sub_on') {
                        label.textContent = 'Player On';
                        assist.style.display = 'none';
                        sub.style.display = 'block';
                    } else if (type === 'sub_off') {
                        label.textContent = 'Player Off';
                        assist.style.display = 'none';
                        sub.style.display = 'none';
                    } else if (type === 'goal') {
                        label.textContent = 'Scorer';
                        assist.style.display = 'block';
                        sub.style.display = 'none';
                    } else {
                        label.textContent = 'Main Player (Scorer/Carded)';
                        assist.style.display = 'none';
                        sub.style.display = 'none';
                    }
                }
                // Initial call to set correct state
                document.addEventListener('DOMContentLoaded', () => {
                    updateEventFields(document.getElementById('eventTypeSelector').value);
                });
            </script>

            <div class="bg-white border border-zinc-100 rounded-2xl overflow-hidden">
                <table class="w-full text-left">
                    <thead class="bg-zinc-50">
                        <tr class="text-[9px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-100">
                            <th class="px-6 py-3">Min</th>
                            <th class="px-6 py-3">Event</th>
                            <th class="px-6 py-3">Team</th>
                            <th class="px-6 py-3">Player</th>
                            <th class="px-6 py-3 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-zinc-50">
                        <?php $__empty_1 = true; $__currentLoopData = $match->matchEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="text-[11px] font-bold text-primary">
                            <td class="px-6 py-3"><?php echo e($event->minute); ?>'</td>
                            <td class="px-6 py-3">
                                <span class="uppercase tracking-tighter"><?php echo e(str_replace('_', ' ', $event->event_type)); ?></span>
                            </td>
                            <td class="px-6 py-3 uppercase"><?php echo e($event->team->name); ?></td>
                            <td class="px-6 py-3 flex items-center gap-2">
                                <?php if($event->player_image_url): ?>
                                <img src="<?php echo e($event->player_image_url); ?>" class="w-6 h-6 rounded-full object-cover border border-zinc-100" alt="">
                                <?php else: ?>
                                <div class="w-6 h-6 rounded-full bg-zinc-100 flex items-center justify-center text-[8px] text-zinc-400 uppercase">
                                    <?php echo e(substr($event->player_name, 0, 1)); ?>

                                </div>
                                <?php endif; ?>
                                <div class="flex flex-col">
                                    <span><?php echo e($event->player_name); ?></span>
                                    <?php if($event->event_type == 'goal' && $event->assistant): ?>
                                        <span class="text-[8px] text-zinc-400">assist: <?php echo e($event->assistant->name); ?></span>
                                    <?php elseif($event->event_type == 'sub_on' && $event->relatedPlayer): ?>
                                        <span class="text-[8px] text-zinc-400">replacing: <?php echo e($event->relatedPlayer->name); ?></span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="px-6 py-3 text-right">
                                <form action="<?php echo e(route('admin.events.destroy', $event->id)); ?>" method="POST" onsubmit="return confirm('Remove this event?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-accent hover:text-red-700 transition">✕</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="px-6 py-8 text-center text-zinc-300 italic">No events recorded yet.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\BAGs\.gemini\antigravity\scratch\local-tournament-laravel\resources\views/admin/edit-fixture.blade.php ENDPATH**/ ?>