

<?php $__env->startSection('title', 'Create Interview'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">
    <div class="bg-white rounded-3xl p-8 shadow-sm border border-zinc-100">
        <form action="<?php echo e(route('admin.interviews.store')); ?>" method="POST" enctype="multipart/form-data" class="space-y-6">
            <?php echo csrf_field(); ?>
            
            <div class="space-y-2">
                <label class="block text-[10px] font-black text-zinc-400 border-b border-zinc-50 pb-2 uppercase tracking-widest">Interview Title</label>
                <input type="text" name="title" class="w-full bg-zinc-50 border border-zinc-100 p-4 rounded-xl font-black text-primary text-xl focus:ring-2 focus:ring-primary outline-none transition uppercase" placeholder="Enter interview title..." required>
            </div>

            <div class="grid grid-cols-2 gap-6">
                <div class="space-y-2">
                    <label class="block text-[10px] font-black text-zinc-400 border-b border-zinc-50 pb-2 uppercase tracking-widest">Interviewee Name</label>
                    <input type="text" name="interviewee_name" class="w-full bg-zinc-50 border border-zinc-100 p-3 rounded-xl font-bold text-primary focus:ring-2 focus:ring-primary outline-none transition text-xs" placeholder="Player or Manager name" required>
                </div>
                <div class="space-y-2">
                    <label class="block text-[10px] font-black text-zinc-400 border-b border-zinc-50 pb-2 uppercase tracking-widest">Role (Optional)</label>
                    <input type="text" name="interviewee_role" class="w-full bg-zinc-50 border border-zinc-100 p-3 rounded-xl font-bold text-primary focus:ring-2 focus:ring-primary outline-none transition text-xs" placeholder="e.g., Forward, Manager">
                </div>
            </div>

            <div class="space-y-2">
                <label class="block text-[10px] font-black text-zinc-400 border-b border-zinc-50 pb-2 uppercase tracking-widest">Description</label>
                <textarea name="description" rows="4" class="w-full bg-zinc-50 border border-zinc-100 p-6 rounded-2xl font-medium text-zinc-700 focus:ring-2 focus:ring-primary outline-none transition text-sm leading-relaxed" placeholder="Brief description of the interview..."></textarea>
            </div>

            <div class="grid grid-cols-2 gap-6">
                <div class="space-y-2">
                    <label class="block text-[10px] font-black text-zinc-400 border-b border-zinc-50 pb-2 uppercase tracking-widest">Video URL (Optional)</label>
                    <input type="url" name="video_url" class="w-full bg-zinc-50 border border-zinc-100 p-3 rounded-xl font-bold text-primary focus:ring-2 focus:ring-primary outline-none transition text-xs" placeholder="https://youtube.com/...">
                </div>
                <div class="space-y-2">
                    <label class="block text-[10px] font-black text-zinc-400 border-b border-zinc-50 pb-2 uppercase tracking-widest">Display Order</label>
                    <input type="number" name="display_order" value="0" class="w-full bg-zinc-50 border border-zinc-100 p-3 rounded-xl font-bold text-primary focus:ring-2 focus:ring-primary outline-none transition text-xs">
                </div>
            </div>

            <div class="space-y-2">
                <label class="block text-[10px] font-black text-zinc-400 border-b border-zinc-50 pb-2 uppercase tracking-widest">Thumbnail Image</label>
                <input type="file" name="thumbnail" class="w-full bg-zinc-50 border border-zinc-100 p-3 rounded-xl font-bold text-primary focus:ring-2 focus:ring-primary outline-none transition text-xs" accept="image/*">
            </div>

            <div class="flex items-center justify-between pt-6 border-t border-zinc-50">
                <label class="flex items-center gap-3 cursor-pointer group">
                    <input type="checkbox" name="is_featured" value="1" class="hidden peer">
                    <div class="w-12 h-6 bg-zinc-200 rounded-full relative transition peer-checked:bg-secondary">
                        <div class="absolute inset-y-1 left-1 w-4 h-4 bg-white rounded-full transition translate-x-0 peer-checked:translate-x-6"></div>
                    </div>
                    <span class="text-[10px] font-black text-zinc-400 uppercase tracking-widest group-hover:text-primary transition">Featured Interview</span>
                </label>

                <div class="flex gap-4">
                    <a href="<?php echo e(route('admin.interviews.index')); ?>" class="px-8 py-3 border border-zinc-100 rounded-xl font-black text-[10px] text-zinc-400 uppercase tracking-widest hover:bg-zinc-50 transition">Cancel</a>
                    <button type="submit" class="bg-primary text-secondary font-black px-12 py-3 rounded-xl hover:scale-105 transition uppercase tracking-widest text-[10px] shadow-lg">Create Interview</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\BAGs\.gemini\antigravity\scratch\local-tournament-laravel\resources\views/admin/interviews/create.blade.php ENDPATH**/ ?>