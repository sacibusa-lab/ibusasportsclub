

<?php $__env->startSection('title', 'Stats Centre'); ?>

<?php $__env->startSection('content'); ?>
<!-- Premium PL Header -->
<div class="relative overflow-hidden bg-primary mb-12 -mx-6 md:-mx-12">
    <div class="absolute inset-0 bg-gradient-to-br from-[#3d195b] via-[#3d195b] to-[#00ff85]/20"></div>
    <div class="absolute right-0 top-0 w-1/2 h-full bg-gradient-to-l from-[#04f5ff]/20 to-transparent"></div>
    
    <div class="relative z-10 max-w-[1400px] mx-auto px-6 py-8 md:py-12">
        <div class="flex items-center gap-6">
            <div class="h-1 bg-secondary w-24"></div>
            <h1 class="text-6xl font-black text-white italic uppercase tracking-tighter">Stats Centre</h1>
        </div>
        <p class="text-secondary/60 mt-4 font-bold uppercase tracking-widest text-sm">2025/26 Season Player Performance</p>
    </div>
</div>

<div class="container mx-auto px-6 pb-24">
    <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        
        <!-- Goals -->
        <?php if(count($topScorers) > 0): ?>
        <div class="space-y-6">
            <div class="flex items-center justify-between border-b-4 border-primary pb-4">
                <h3 class="text-2xl font-black text-primary uppercase italic tracking-tight">Goals</h3>
                <span class="text-2xl">⚽</span>
            </div>
            <div class="space-y-4">
                <?php $__currentLoopData = $topScorers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex items-center justify-between p-4 bg-white rounded-2xl shadow-sm border border-zinc-100 hover:border-secondary transition-all group">
                    <div class="flex items-center gap-4">
                        <span class="text-xl font-black text-zinc-300 italic w-6"><?php echo e($index + 1); ?></span>
                        <div class="relative">
                            <?php if($player->image_url): ?>
                            <img src="<?php echo e($player->image_url); ?>" class="w-12 h-12 rounded-full object-cover border-2 border-zinc-50">
                            <?php else: ?>
                            <div class="w-12 h-12 bg-zinc-100 rounded-full flex items-center justify-center font-black text-zinc-400 text-xs">
                                <?php echo e(substr($player->name, 0, 1)); ?>

                            </div>
                            <?php endif; ?>
                        </div>
                        <div>
                            <p class="font-black text-primary text-sm leading-none uppercase"><?php echo e($player->name); ?></p>
                            <div class="flex items-center gap-1.5 mt-1">
                                <?php if($player->team->logo_url): ?>
                                <img src="<?php echo e($player->team->logo_url); ?>" class="w-3 h-3 object-contain opacity-80">
                                <?php endif; ?>
                                <p class="text-[9px] font-bold text-zinc-400 uppercase tracking-tight"><?php echo e($player->team->name); ?></p>
                            </div>
                        </div>
                    </div>
                    <span class="text-2xl font-black text-primary italic"><?php echo e($player->goals_count); ?></span>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Assists -->
        <?php if(count($topAssists) > 0): ?>
        <div class="space-y-6">
            <div class="flex items-center justify-between border-b-4 border-primary pb-4">
                <h3 class="text-2xl font-black text-primary uppercase italic tracking-tight">Assists</h3>
                <span class="text-2xl">🎯</span>
            </div>
            <div class="space-y-4">
                <?php $__currentLoopData = $topAssists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex items-center justify-between p-4 bg-white rounded-2xl shadow-sm border border-zinc-100 hover:border-secondary transition-all group">
                    <div class="flex items-center gap-4">
                        <span class="text-xl font-black text-zinc-300 italic w-6"><?php echo e($index + 1); ?></span>
                        <div class="relative">
                            <?php if($player->image_url): ?>
                            <img src="<?php echo e($player->image_url); ?>" class="w-12 h-12 rounded-full object-cover border-2 border-zinc-50">
                            <?php else: ?>
                            <div class="w-12 h-12 bg-zinc-100 rounded-full flex items-center justify-center font-black text-zinc-400 text-xs">
                                <?php echo e(substr($player->name, 0, 1)); ?>

                            </div>
                            <?php endif; ?>
                        </div>
                        <div>
                            <p class="font-black text-primary text-sm leading-none uppercase"><?php echo e($player->name); ?></p>
                            <div class="flex items-center gap-1.5 mt-1">
                                <?php if($player->team->logo_url): ?>
                                <img src="<?php echo e($player->team->logo_url); ?>" class="w-3 h-3 object-contain opacity-80">
                                <?php endif; ?>
                                <p class="text-[9px] font-bold text-zinc-400 uppercase tracking-tight"><?php echo e($player->team->name); ?></p>
                            </div>
                        </div>
                    </div>
                    <span class="text-2xl font-black text-primary italic"><?php echo e($player->assists_count); ?></span>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Clean Sheets -->
        <?php if(count($topCleanSheets) > 0): ?>
        <div class="space-y-6">
            <div class="flex items-center justify-between border-b-4 border-primary pb-4">
                <h3 class="text-2xl font-black text-primary uppercase italic tracking-tight">Clean Sheets</h3>
                <span class="text-2xl">🧤</span>
            </div>
            <div class="space-y-4">
                <?php $__currentLoopData = $topCleanSheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex items-center justify-between p-4 bg-white rounded-2xl shadow-sm border border-zinc-100 hover:border-secondary transition-all group">
                    <div class="flex items-center gap-4">
                        <span class="text-xl font-black text-zinc-300 italic w-6"><?php echo e($index + 1); ?></span>
                        <div class="relative">
                            <?php if($player->image_url): ?>
                            <img src="<?php echo e($player->image_url); ?>" class="w-12 h-12 rounded-full object-cover border-2 border-zinc-50">
                            <?php else: ?>
                            <div class="w-12 h-12 bg-zinc-100 rounded-full flex items-center justify-center font-black text-zinc-400 text-xs">
                                <?php echo e(substr($player->name, 0, 1)); ?>

                            </div>
                            <?php endif; ?>
                        </div>
                        <div>
                            <p class="font-black text-primary text-sm leading-none uppercase"><?php echo e($player->name); ?></p>
                            <div class="flex items-center gap-1.5 mt-1">
                                <?php if($player->team->logo_url): ?>
                                <img src="<?php echo e($player->team->logo_url); ?>" class="w-3 h-3 object-contain opacity-80">
                                <?php endif; ?>
                                <p class="text-[9px] font-bold text-zinc-400 uppercase tracking-tight"><?php echo e($player->team->name); ?></p>
                            </div>
                        </div>
                    </div>
                    <span class="text-2xl font-black text-primary italic"><?php echo e($player->clean_sheets_count); ?></span>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Discipline -->
        <?php if(count($topCards) > 0): ?>
        <div class="space-y-6">
            <div class="flex items-center justify-between border-b-4 border-primary pb-4">
                <h3 class="text-2xl font-black text-primary uppercase italic tracking-tight">Discipline</h3>
                <span class="text-2xl">🟨</span>
            </div>
            <div class="space-y-4">
                <?php $__currentLoopData = $topCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex items-center justify-between p-4 bg-white rounded-2xl shadow-sm border border-zinc-100 hover:border-secondary transition-all group">
                    <div class="flex items-center gap-4">
                        <span class="text-xl font-black text-zinc-300 italic w-6"><?php echo e($index + 1); ?></span>
                        <div class="relative">
                            <?php if($player->image_url): ?>
                            <img src="<?php echo e($player->image_url); ?>" class="w-12 h-12 rounded-full object-cover border-2 border-zinc-50">
                            <?php else: ?>
                            <div class="w-12 h-12 bg-zinc-100 rounded-full flex items-center justify-center font-black text-zinc-400 text-xs">
                                <?php echo e(substr($player->name, 0, 1)); ?>

                            </div>
                            <?php endif; ?>
                        </div>
                        <div>
                            <p class="font-black text-primary text-sm leading-none uppercase"><?php echo e($player->name); ?></p>
                            <div class="flex items-center gap-1.5 mt-1">
                                <?php if($player->team->logo_url): ?>
                                <img src="<?php echo e($player->team->logo_url); ?>" class="w-3 h-3 object-contain opacity-80">
                                <?php endif; ?>
                                <p class="text-[9px] font-bold text-zinc-400 uppercase tracking-tight"><?php echo e($player->team->name); ?></p>
                            </div>
                        </div>
                    </div>
                    <span class="text-2xl font-black text-primary italic"><?php echo e($player->cards_count); ?></span>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Man of the Match -->
        <?php if(count($topMOTM) > 0): ?>
        <div class="space-y-6">
            <div class="flex items-center justify-between border-b-4 border-secondary pb-4">
                <h3 class="text-2xl font-black text-primary uppercase italic tracking-tight font-body">Man of the Match</h3>
                <span class="text-2xl">🏆</span>
            </div>
            <div class="space-y-4">
                <?php $__currentLoopData = $topMOTM; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex items-center justify-between p-4 bg-white rounded-2xl shadow-sm border border-zinc-100 hover:border-secondary transition-all group">
                    <div class="flex items-center gap-4">
                        <span class="text-xl font-black text-zinc-300 italic w-6"><?php echo e($index + 1); ?></span>
                        <div class="relative">
                            <?php if($player->image_url): ?>
                            <img src="<?php echo e($player->image_url); ?>" class="w-12 h-12 rounded-full object-cover border-2 border-zinc-50">
                            <?php else: ?>
                            <div class="w-12 h-12 bg-zinc-100 rounded-full flex items-center justify-center font-black text-zinc-400 text-xs">
                                <?php echo e(substr($player->name, 0, 1)); ?>

                            </div>
                            <?php endif; ?>
                        </div>
                        <div>
                            <p class="font-black text-primary text-sm leading-none uppercase"><?php echo e($player->name); ?></p>
                            <div class="flex items-center gap-1.5 mt-1">
                                <?php if($player->team->logo_url): ?>
                                <img src="<?php echo e($player->team->logo_url); ?>" class="w-3 h-3 object-contain opacity-80">
                                <?php endif; ?>
                                <p class="text-[9px] font-bold text-zinc-400 uppercase tracking-tight"><?php echo e($player->team->name); ?></p>
                            </div>
                        </div>
                    </div>
                    <span class="text-2xl font-black text-primary italic"><?php echo e($player->motm_awards_count); ?></span>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\BAGs\.gemini\antigravity\scratch\local-tournament-laravel\resources\views/stats.blade.php ENDPATH**/ ?>