

<?php $__env->startSection('content'); ?>
<div class="space-y-12">
    <div class="flex items-center justify-between border-b border-zinc-100 pb-8">
        <h2 class="text-4xl font-black text-primary uppercase tracking-tighter italic">Latest News</h2>
        <div class="flex gap-4 overflow-x-auto no-scrollbar pb-2">
            <a href="<?php echo e(route('news.index')); ?>" class="px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition <?php echo e(!request('category') ? 'bg-primary text-secondary shadow-lg' : 'bg-white text-zinc-400 border border-zinc-100'); ?>">All</a>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('news.index', ['category' => $cat->slug])); ?>" class="px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition <?php echo e(request('category') == $cat->slug ? 'bg-primary text-secondary shadow-lg' : 'bg-white text-zinc-400 border border-zinc-100'); ?>"><?php echo e($cat->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="bg-white rounded-2xl overflow-hidden shadow-sm border border-zinc-100 hover:shadow-xl transition-all group flex flex-col">
            <div class="aspect-video relative overflow-hidden bg-zinc-100">
                <?php if($post->image_url): ?>
                <img src="<?php echo e($post->image_url); ?>" alt="<?php echo e($post->title); ?>" class="w-full h-full object-cover transition duration-700 group-hover:scale-110">
                <?php endif; ?>
                <div class="absolute top-4 left-4">
                    <span class="bg-primary text-secondary text-[9px] font-black px-3 py-1 rounded uppercase tracking-widest shadow-lg"><?php echo e($post->category->name); ?></span>
                </div>
            </div>
            <div class="p-8 flex-1 flex flex-col">
                <div class="text-[9px] font-black text-zinc-300 uppercase tracking-widest mb-3 flex items-center gap-2">
                    <span><?php echo e($post->published_at ? $post->published_at->format('j F Y') : $post->created_at->format('j F Y')); ?></span>
                    <span>•</span>
                    <span><?php echo e(ceil(str_word_count(strip_tags($post->content)) / 200)); ?> Min Read</span>
                </div>
                <h3 class="text-xl font-black text-primary mb-4 leading-tight group-hover:text-secondary transition uppercase tracking-tighter line-clamp-2">
                    <a href="<?php echo e(route('news.show', $post->slug)); ?>"><?php echo e($post->title); ?></a>
                </h3>
                <p class="text-zinc-500 text-sm leading-relaxed line-clamp-3 mb-6 font-medium"><?php echo e(Str::limit(strip_tags($post->content), 120)); ?></p>
                <div class="mt-auto pt-6 border-t border-zinc-50 flex items-center justify-between">
                    <div class="flex flex-wrap gap-1">
                        <?php $__currentLoopData = $post->tags->take(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="text-[8px] font-black text-zinc-300 uppercase">#<?php echo e($tag->name); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a href="<?php echo e(route('news.show', $post->slug)); ?>" class="text-primary hover:text-secondary transition text-xs font-black italic uppercase tracking-widest">Read More →</a>
                </div>
            </div>
        </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-span-full py-20 text-center">
            <p class="text-zinc-300 font-black uppercase tracking-widest text-sm italic">No articles found in this section.</p>
        </div>
        <?php endif; ?>
    </div>

    <div class="pt-12">
        <?php echo e($posts->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\BAGs\.gemini\antigravity\scratch\local-tournament-laravel\resources\views/news/index.blade.php ENDPATH**/ ?>