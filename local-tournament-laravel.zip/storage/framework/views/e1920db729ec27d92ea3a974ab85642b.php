

<?php $__env->startSection('title', 'Manage Categories'); ?>

<?php $__env->startSection('content'); ?>
<div class="grid lg:grid-cols-3 gap-12">
    <!-- Category Form -->
    <div class="lg:col-span-1">
        <div class="bg-white rounded-3xl p-8 shadow-sm border border-zinc-100">
            <h3 class="text-xs font-black text-primary uppercase tracking-widest mb-6 border-b border-zinc-50 pb-4">Add New Category</h3>
            <form action="<?php echo e(route('admin.news.categories.store')); ?>" method="POST" class="space-y-4">
                <?php echo csrf_field(); ?>
                <div class="space-y-2">
                    <label class="text-[9px] font-black text-zinc-400 uppercase tracking-widest">Category Name</label>
                    <input type="text" name="name" class="w-full bg-zinc-50 border border-zinc-100 p-4 rounded-2xl font-bold text-primary focus:ring-2 focus:ring-primary outline-none transition uppercase text-xs" placeholder="e.g. Announcements" required>
                </div>
                <button type="submit" class="w-full bg-primary text-secondary font-black py-4 rounded-2xl hover:bg-primary-light transition uppercase tracking-widest text-[10px] shadow-lg">Create Category</button>
            </form>
        </div>
    </div>

    <!-- Category Table -->
    <div class="lg:col-span-2">
        <div class="bg-white rounded-3xl shadow-sm border border-zinc-100 overflow-hidden">
            <table class="w-full text-left">
                <thead>
                    <tr class="bg-zinc-50 text-zinc-400 text-[10px] font-black uppercase tracking-widest border-b border-zinc-100">
                        <th class="px-6 py-4">Name</th>
                        <th class="px-6 py-4">Posts</th>
                        <th class="px-6 py-4 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-zinc-50">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-zinc-50 transition">
                        <td class="px-6 py-4">
                            <span class="font-extrabold text-primary text-sm uppercase tracking-tighter"><?php echo e($category->name); ?></span>
                        </td>
                        <td class="px-6 py-4 text-xs font-bold text-zinc-400 italic">
                            <?php echo e($category->posts_count); ?> Articles
                        </td>
                        <td class="px-6 py-4 text-right">
                            <form action="<?php echo e(route('admin.news.categories.destroy', $category->id)); ?>" method="POST" onsubmit="return confirm('Delete category? All posts in it will be lost!')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="p-2 text-zinc-300 hover:text-accent transition">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\BAGs\.gemini\antigravity\scratch\local-tournament-laravel\resources\views/admin/news/categories.blade.php ENDPATH**/ ?>